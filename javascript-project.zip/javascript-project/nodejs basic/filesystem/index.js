// TODO: tampilkan teks pada notes.txt pada console.
const fs = require('fs');
const path = require('path');
const link = path.resolve(__dirname, 'notes.txt')
const fileReadCallback = (error,data) => {
    if(error){
        console.log('Gagal Membaca Berkas');
        return;
    }
    console.log(data);
};

fs.readFile(link, 'UTF-8', fileReadCallback);